package com.example.eventdicoding.ui.detail

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.text.HtmlCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.eventdicoding.data.response.ListEventsItem
import com.example.eventdicoding.databinding.FragmentDetailBinding

class DetailFragment : Fragment() {

    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Mengatur listener untuk tombol back di toolbar
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp() // Kembali ke fragment sebelumnya
        }

        // Mengambil data selectedEvent dari arguments
        val selectedEvent = arguments?.getParcelable<ListEventsItem>("selectedEvent")

        // Jika selectedEvent tidak null, tampilkan data di UI
        selectedEvent?.let { event ->
            binding.apply {
                // Mengatur data yang diterima pada elemen UI
                tvEventName.text = event.name
                tvEventDate.text = event.beginTime
                tvEventLocation.text = event.cityName
                tvOrganizerName.text = event.ownerName
                tvQuota.text = "${event.quota - event.registrants} sisa kuota"

                // Menampilkan deskripsi dengan format HTML agar lebih rapi
                tvEventDescription.text = HtmlCompat.fromHtml(event.description, HtmlCompat.FROM_HTML_MODE_LEGACY)

                // Menampilkan gambar menggunakan Glide
                Glide.with(this@DetailFragment)
                    .load(event.mediaCover)
                    .into(ivEventImage)

                // Tombol untuk membuka link acara
                binding.btnOpenLink.setOnClickListener {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(event.link))
                    startActivity(intent)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
