package com.example.eventdicoding.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.eventdicoding.data.response.ListEventsItem
import com.example.eventdicoding.databinding.ItemEventGridBinding
import com.example.eventdicoding.databinding.ItemEventVerticalBinding

class EventAdapter(
    private val isHorizontalLayout: Boolean = false, // Tambahkan parameter untuk Horizontal
    private val isGridLayout: Boolean = false, // Tambahkan parameter untuk Grid
    private val onItemClick: (ListEventsItem) -> Unit
) : ListAdapter<ListEventsItem, RecyclerView.ViewHolder>(DIFF_CALLBACK) {

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListEventsItem>() {
            override fun areItemsTheSame(oldItem: ListEventsItem, newItem: ListEventsItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: ListEventsItem, newItem: ListEventsItem): Boolean {
                return oldItem == newItem
            }
        }
    }

    // ViewHolder untuk tampilan Horizontal
    inner class HorizontalViewHolder(private val binding: ItemEventVerticalBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.tvEventName.text = event.name
            Glide.with(binding.ivEventImage.context).load(event.imageLogo).into(binding.ivEventImage)
            binding.root.setOnClickListener { onItemClick(event) }
        }
    }

    // ViewHolder untuk tampilan Grid
    inner class GridViewHolder(private val binding: ItemEventGridBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.tvEventName.text = event.name
            Glide.with(binding.ivEventImage.context).load(event.imageLogo).into(binding.ivEventImage)
            binding.root.setOnClickListener { onItemClick(event) }
        }
    }

    // ViewHolder untuk tampilan Vertikal (Default)
    inner class VerticalViewHolder(private val binding: ItemEventVerticalBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.tvEventName.text = event.name
            binding.tvEventTime.text = event.beginTime
            Glide.with(binding.ivEventImage.context).load(event.imageLogo).into(binding.ivEventImage)
            binding.root.setOnClickListener { onItemClick(event) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when {
            isHorizontalLayout -> HorizontalViewHolder(
                ItemEventVerticalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
            isGridLayout -> GridViewHolder(
                ItemEventGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
            else -> VerticalViewHolder(
                ItemEventVerticalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val event = getItem(position)
        when (holder) {
            is HorizontalViewHolder -> holder.bind(event)
            is GridViewHolder -> holder.bind(event)
            is VerticalViewHolder -> holder.bind(event)
        }
    }
}
